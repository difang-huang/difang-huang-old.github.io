clear;clc;close all;
load IntEquity

 
mu=mean(R*100);
Sigma=cov(R*100);
T=size(R,1);

nsims=1000;

RisklessRate=5/12;
BorrowRate=5/12;
RiskAversion=3;
AssetBoundsNC=[-1; 1]*ones(1,6);
AssetBoundsC=[0; 0.3]*ones(1,6);

[PortRiskTNC, PortReturnTNC, PortWtsTNC] = frontcon(mu,Sigma,50,[],AssetBoundsNC);
[OPTRiskTNC, OPTReturnTNC, RiskyWtsTNC] = portalloc(PortRiskTNC, PortReturnTNC, PortWtsTNC, RisklessRate, BorrowRate, RiskAversion);

[PortRiskTC, PortReturnTC, PortWtsTC] = frontcon(mu,Sigma,50,[],AssetBoundsC);
[OPTRiskTC, OPTReturnTC, RiskyWtsTC] = portalloc(PortRiskTC, PortReturnTC, PortWtsTC, RisklessRate, BorrowRate, RiskAversion);

RR=portsim(mu,Sigma,T,1,nsims,'Expected');

for i=1:nsims
    
muHAT=mean(RR(:,:,i));
SigmaHAT=cov(RR(:,:,i));

muHATadj=1/2*mean(RR(:,:,i))+1/2;


[PortRiskNC, PortReturnNC, PortWtsNC] = frontcon(muHAT,SigmaHAT,50,[],AssetBoundsNC);
[RiskyRisk, RiskyReturn, RiskyWtsNC(i,:)] = portalloc(PortRiskNC, PortReturnNC, PortWtsNC, RisklessRate, BorrowRate, RiskAversion);

[PortRiskC, PortReturnC, PortWtsC] = frontcon(muHAT,SigmaHAT,50,[],AssetBoundsC);
[RiskyRiskC, RiskyReturnC, RiskyWtsC(i,:)] = portalloc(PortRiskC, PortReturnC, PortWtsC, RisklessRate, BorrowRate, RiskAversion);

[PortRiskNCadj, PortReturnNCadj, PortWtsNCadj] = frontcon(muHATadj,SigmaHAT,50,[],AssetBoundsNC);
[RiskyRiskadj, RiskyReturnadj, RiskyWtsNCadj(i,:)] = portalloc(PortRiskNCadj, PortReturnNCadj, PortWtsNC, RisklessRate, BorrowRate, RiskAversion);


% Find actual mean and volatility of in-sample portfolio
OPTReturnSNC(i,:)=mu*RiskyWtsNC(i,:)';
OPTRiskSNC(i,:)=sqrt(RiskyWtsNC(i,:)*Sigma*RiskyWtsNC(i,:)');

OPTReturnSC(i,:)=mu*RiskyWtsC(i,:)';
OPTRiskSC(i,:)=sqrt(RiskyWtsC(i,:)*Sigma*RiskyWtsC(i,:)'); 

OPTReturnSNCadj(i,:)=mu*RiskyWtsNCadj(i,:)';
OPTRiskSNCadj(i,:)=sqrt(RiskyWtsNCadj(i,:)*Sigma*RiskyWtsNCadj(i,:)');

EwWts=ones(1,6)/6;

OPTReturnEW(i,:)=mu*EwWts';
OPTRiskEW(i,:)=sqrt(EwWts*Sigma*EwWts'); 

RiskParityWts=(diag(SigmaHAT).^(-1));
RiskParityWts=RiskParityWts'/sum(RiskParityWts);

unity=ones(6,1);
A = unity'*SigmaHAT^-1*unity;
GMVwts = (SigmaHAT^-1*unity)/A;
GMVwts=GMVwts';

OPTReturnRP(i,:)=mu*RiskParityWts';
OPTRiskRP(i,:)=sqrt(RiskParityWts*Sigma*RiskParityWts'); 

OPTReturnGMV(i,:)=mu*GMVwts';
OPTRiskGMV(i,:)=sqrt(GMVwts*Sigma*GMVwts'); 

end
 
mn1=max(hist(RiskyWtsNC(:,1),20));
mn2=max(hist(RiskyWtsNC(:,2),20));
mn3=max(hist(RiskyWtsNC(:,3),20));
mn4=max(hist(RiskyWtsNC(:,4),20));
mn5=max(hist(RiskyWtsNC(:,5),20));
mn6=max(hist(RiskyWtsNC(:,6),20));

axes1 = axes('FontSize',16);
figure(1);hist(axes1,RiskyWtsNC(:,1),20);line([RiskyWtsTNC(1) RiskyWtsTNC(1)],[0 nsims],'LineWidth',3,'Color','k');title(names{1},'FontSize',18);ylim([0 mn1*1.2]);box off;saveas(figure(1),names{1},'epsc');close all
axes1 = axes('FontSize',16);
figure(1);hist(axes1,RiskyWtsNC(:,2),20);line([RiskyWtsTNC(2) RiskyWtsTNC(2)],[0 nsims],'LineWidth',3,'Color','k');title(names{2},'FontSize',18);ylim([0 mn2*1.2]);box off;saveas(figure(1),names{2},'epsc');close all
axes1 = axes('FontSize',16);
figure(1);hist(axes1,RiskyWtsNC(:,3),20);line([RiskyWtsTNC(3) RiskyWtsTNC(3)],[0 nsims],'LineWidth',3,'Color','k');title(names{3},'FontSize',18);ylim([0 mn3*1.2]);box off;saveas(figure(1),names{3},'epsc');close all
axes1 = axes('FontSize',16);
figure(1);hist(axes1,RiskyWtsNC(:,4),20);line([RiskyWtsTNC(4) RiskyWtsTNC(4)],[0 nsims],'LineWidth',3,'Color','k');title(names{4},'FontSize',18);ylim([0 mn4*1.2]);box off;saveas(figure(1),names{4},'epsc');close all
axes1 = axes('FontSize',16);
figure(1);hist(axes1,RiskyWtsNC(:,5),20);line([RiskyWtsTNC(5) RiskyWtsTNC(5)],[0 nsims],'LineWidth',3,'Color','k');title(names{5},'FontSize',18);ylim([0 mn5*1.2]);box off;saveas(figure(1),names{5},'epsc');close all
axes1 = axes('FontSize',16);
figure(1);hist(axes1,RiskyWtsNC(:,6),20);line([RiskyWtsTNC(6) RiskyWtsTNC(6)],[0 nsims],'LineWidth',3,'Color','k');title(names{6},'FontSize',18);ylim([0 mn6*1.2]);box off;saveas(figure(1),names{6},'epsc');close all

 
close all
axes1 = axes('FontSize',16);
plot(PortRiskTNC, PortReturnTNC,'LineWidth',3);hold on;scatter(OPTRiskTNC,OPTReturnTNC,100,'k','filled');scatter(OPTRiskSNC,OPTReturnSNC,2,'b','*');hold off;box off;
line([0 2*OPTRiskTNC],[RisklessRate  RisklessRate+2*(OPTReturnTNC-RisklessRate)],'LineWidth',2,'Color','k');xlabel('\sigma');ylabel('\mu')
for ii=1:6
text(sqrt(Sigma(ii,ii)),mu(ii),names(ii),'FontSize',12)
end
xlim([0 8])
ylim([0.2 1.6])
saveas(gcf,'MVsim','epsc');



hist((OPTReturnSNC-RisklessRate)./OPTRiskSNC); 
saveas(gcf,'MVsim_SRhist','epsc');





close all
axes1 = axes('FontSize',16);
plot(PortRiskTNC, PortReturnTNC,'LineWidth',3);hold on;scatter(OPTRiskTNC,OPTReturnTNC,100,'b','filled');scatter(OPTRiskSNC,OPTReturnSNC,2,'b','*');
plot(PortRiskTC, PortReturnTC,'r','LineWidth',3);
scatter(OPTRiskTC,OPTReturnTC,100,'r','filled');scatter(OPTRiskSC,OPTReturnSC,2,'r','*');
hold off;box off;
xlabel('\sigma');ylabel('\mu')
for ii=1:6
text(sqrt(Sigma(ii,ii)),mu(ii),names(ii),'FontSize',12)
end
xlim([3 7])
ylim([0.75 1.35])
saveas(gcf,'MVsim2','epsc');

hist((OPTReturnSC-RisklessRate)./OPTRiskSC); 
saveas(gcf,'MVsim_SRhist2','epsc');



close all
axes1 = axes('FontSize',16);
plot(PortRiskTNC, PortReturnTNC,'LineWidth',3);hold on;scatter(OPTRiskTNC,OPTReturnTNC,100,'b','filled');scatter(OPTRiskSNC,OPTReturnSNC,2,'b','*');
scatter(OPTRiskSNCadj,OPTReturnSNCadj,2,'r','*');
hold off;box off;
xlabel('\sigma');ylabel('\mu')
for ii=1:6
text(sqrt(Sigma(ii,ii)),mu(ii),names(ii),'FontSize',12)
end
xlim([3 7])
ylim([0.75 1.35])
saveas(gcf,'MVsim2adj','epsc');

hist((OPTReturnSC-RisklessRate)./OPTRiskSC); 
saveas(gcf,'MVsim_SRhist2adj','epsc');


close all
axes1 = axes('FontSize',16);
plot(PortRiskTNC, PortReturnTNC,'LineWidth',3);hold on;scatter(OPTRiskTNC,OPTReturnTNC,100,'b','filled');scatter(OPTRiskSNC,OPTReturnSNC,2,'b','*');
scatter(OPTRiskEW,OPTReturnEW,500,'r','.');
hold off;box off;
xlabel('\sigma');ylabel('\mu')
for ii=1:6
text(sqrt(Sigma(ii,ii)),mu(ii),names(ii),'FontSize',12)
end
xlim([3 7])
ylim([0.75 1.35])
saveas(gcf,'MVsim3','epsc');



close all
axes1 = axes('FontSize',16);
plot(PortRiskTNC, PortReturnTNC,'LineWidth',3);hold on;scatter(OPTRiskTNC,OPTReturnTNC,100,'b','filled');scatter(OPTRiskSNC,OPTReturnSNC,2,'b','*');
scatter(OPTRiskRP,OPTReturnRP,2,'r','*');
hold off;box off;
xlabel('\sigma');ylabel('\mu')
for ii=1:6
text(sqrt(Sigma(ii,ii)),mu(ii),names(ii),'FontSize',12)
end
xlim([3 7])
ylim([0.75 1.35])
saveas(gcf,'MVsim_RP','epsc');
hist((OPTReturnRP-RisklessRate)./OPTRiskRP); 
saveas(gcf,'MVsim_SR_RP','epsc');



close all
axes1 = axes('FontSize',16);
plot(PortRiskTNC, PortReturnTNC,'LineWidth',3);hold on;scatter(OPTRiskTNC,OPTReturnTNC,100,'b','filled');scatter(OPTRiskSNC,OPTReturnSNC,2,'b','*');
scatter(OPTRiskGMV,OPTReturnGMV,2,'r','*');
hold off;box off;
xlabel('\sigma');ylabel('\mu')
for ii=1:6
text(sqrt(Sigma(ii,ii)),mu(ii),names(ii),'FontSize',12)
end
xlim([3 7])
ylim([0.75 1.35])
saveas(gcf,'MVsim_GMV','epsc');
hist((OPTReturnGMV-RisklessRate)./OPTRiskGMV); 
saveas(gcf,'MVsim_SR_GMV','epsc');





return
close all
axes1 = axes('FontSize',16);
plot(R(:,1));title(names{1},'FontSize',18);box off;xlim([0 510])
saveas(gcf,'R1','epsc');
close all
axes1 = axes('FontSize',16);
plot(R(:,2));title(names{2},'FontSize',18);box off;xlim([0 510])
saveas(gcf,'R2','epsc');
close all
axes1 = axes('FontSize',16);
plot(R(:,3));title(names{3},'FontSize',18);box off;xlim([0 510])
saveas(gcf,'R3','epsc');
close all
axes1 = axes('FontSize',16);
plot(R(:,4));title(names{4},'FontSize',18);box off;xlim([0 510])
saveas(gcf,'R4','epsc');
close all
axes1 = axes('FontSize',16);
plot(R(:,5));title(names{5},'FontSize',18);box off;xlim([0 510])
saveas(gcf,'R5','epsc');
close all
axes1 = axes('FontSize',16);
plot(R(:,6));title(names{6},'FontSize',18);box off;xlim([0 510])
saveas(gcf,'R6','epsc');
close all
 






