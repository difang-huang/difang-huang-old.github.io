This folder contains data and estimation programs for Investment, Idiosyncratic risk and Ownership.

The programs are written in Stata 11 and require a number of third party software that can be installed with the net search/install command. In particular, they make use of ivreg2, xtabond2, eststo, estout and esttab. 

Our programs reproduce the results in the paper:

Table 1: PP_BENCH.do
Table 2: PP_SUMMARY.do
Table 3: PP_INSIDE.do
Table 4: PP_VEGAxINSID.do
Table 5: PP_INSTxINSID.do
Table 6: PP_ALT_Q.do and PP_IV.do
Table 7: PP_FINCxINSID.do
Table 8: PP_IRREVxCOMPxOWN.do and PP_IRREVxMPxOWN.do

Unless you choose to save the data file in the default stata directory , the preamble of the .do file needs to be edited to point Stata to our data files (PPdata.dta) using the stata cd command.

These programs generate LaTeX output of the corresponding tables using estout, with the appropriate formatting. 