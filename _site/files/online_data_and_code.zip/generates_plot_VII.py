# file: generates_plot_VII.py
#
# "Growth under the Shadow of Expropriation"
#
# Mark Aguiar and Manuel Amador
#
# September 2010 
#
# After running the appropriate simulations in "simulation_class.py" the
# following code reads the output in simulation_data.dat and generates figure
# VII. "simulation_class.py" most be in the same path. 
#
# Python 2.6 code

from __future__ import division
from matplotlib import use, rc
use('Agg') # forces matplotlib to use a Non-GUI interface
rc('text', usetex=True)
from matplotlib import pyplot as plt
from scipy import log, optimize
import sys, shelve
from simulation_class import ModelSimulation, MarkovHyperbolic, ChebyshevPoly

fig_format = 'eps'

fname = 'simulation_data.dat'
d = shelve.open(fname)
g = []
keys = [("sig:1, b:0.83, r:0.2, a:0.33, d:0.2, th:3, oo:agu, t_bar:0.6", "AA"),
        ("sig:1, b:0.83, r:0.2, a:0.33, d:0.2, th:1, oo:hyp, loss:0", "RCK"),
        ("sig:1, b:0.63, r:0.2, a:0.33, d:0.2, th:1, oo:hyp, loss:0", "BL"),
        ("sig:1, b:0.83, r:0.2, a:0.33, d:0.2, th:3, oo:hyp, loss:0", "AA2")
]

plt.close('all')
try:
    for (lin,ki, markers) in zip([ 'k-o', 'k--', 'k-s', 'k:', 'k-^'], keys,
                                 [800, 100, 100, 100, 100]):
        k = ki[0]
        lab = ki[1]
        plt.figure(1, figsize=(5,5))
        print(k)
        m = d[k]
        x1 = log(m.f(m.kmap['kt'])/m.f(m.kss))
        y1 = (1/5.0) * log(m.f(m.kmap['kt+1'])/m.f(m.kmap['kt']))
        plt.plot([x1[50 * i] for i in range(len(x1)/50)] + [x1[-1]] ,
                 [y1[50 * i] for i in range(len(y1)/50)] + [y1[-1]],
                 lin, label=lab, linewidth=1, markevery=markers / 50)
    plt.xlabel(r'$\log \left(y_t/y_{ss}\right)$')
    plt.ylabel(r'$\log \left(y_{t+1}/y_t\right) / T$')
    k = "sig:1, b:0.83, r:0.2, a:0.33, d:0.2, th:3, oo:hyp, loss:0"    
    m = d[k]
    kgrid = m.hyper.kgrid
    kpol  = m.hyper.g(m.hyper.kgrid, m.hyper.gpol)
    kss = optimize.brentq(lambda kk: m.hyper.g(kk, m.hyper.gpol) - kk, m.kstar
                         * 0.01, m.kstar)
    plt.plot(log(m.hyper.f(kgrid)/m.hyper.f(kss)),
                 (1/5.0) * log(m.hyper.f(kpol)/m.hyper.f(kgrid)), 'k-',
                 label= "HYPER", linewidth=1, markevery=300)
    plt.legend(loc=0)
    plt.ylim([-.004,.05])
    plt.xlim([-.4, .03])
finally:
    d.close()
plt.savefig('plotVII.' + fig_format, format=fig_format)

