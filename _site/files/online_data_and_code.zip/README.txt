"Growth in the Shadow of Expropriation"

Mark Aguiar and Manuel Amador

September 2010

Online data and code appendix 

All the code is in Python 2.6. To run a python file, just download the appropriate 
python distribution for your computer from http://www.python.org 

* Description of the files: 

  - File "data_www.csv" contains the raw data used for plots I and II of the paper. 
 
  - File "data_work.py" contains the Python code to generate plots I
    and II. File "data_work.nb" generates the plots in Mathematica.

  - File "speed_convergence.py" contains the code to generate the speeds of
    convergence for the linearized model. 

  - File "simulation_class.py" contains the main code that runs the simulations of
    the model. It outputs the outcome of the simulations into the
    file "simulation_data.py". 

    IMPORTANT: This file should be run before "generate_plots_IV_V_VI.py" and
    "generates_plot_VII.py".

  - File "generates_plots_IV_V_VI.py" uses simulation_data.py to generate figures
    IV, V and VI of the paper. 

  - File "generate_plot_VII.py" uses simulation_data.py to generate figure VII of
    the paper.

* Usage

In a Linux distribution, from the command line, issue the following commands:

$ python data_work.py

$ python simulation_class.py

$ python generate_plots_IV_V_VI.py

$ python generate_plot_VII.py

$ python speed_convergence.py

And figures will be generated in the current directory. 

Be sure that you have python, as well as the numpy and scipy packages installed in 
your machine. 



