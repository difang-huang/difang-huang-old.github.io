# file: generate_plots_IV_V_VI.py
#
# "Growth under the Shadow of Expropriation"
#
# Mark Aguiar and Manuel Amador
#
# September 2010 
#
# After running the appropriate simulations in "simulation_class.py" the
# following code reads the output in simulation_data.dat and generates figures
# IV, V and IV in the paper. "simulation_class.py" most be in the same path. 
#
# Python 2.6 code

from __future__ import division
from matplotlib import use, rc
use('Agg') # forces matplotlib to use a Non-GUI interface
rc('text', usetex=True)

from matplotlib import pyplot as plt
from scipy import log 
import sys, shelve
from simulation_class import ModelSimulation 
fig_format = 'eps'

plt.close('all')
fname = 'simulation_data.dat'
d = shelve.open(fname)
keys = ["sig:1, b:0.83, r:0.2, a:0.33, d:0.2, th:1, oo:agu, t_bar:0.6",
        "sig:1, b:0.83, r:0.2, a:0.33, d:0.2, th:3, oo:agu, t_bar:0.6",
        "sig:1, b:0.83, r:0.2, a:0.33, d:0.2, th:5, oo:agu, t_bar:0.6",
        "sig:1, b:0.83, r:0.2, a:0.33, d:0.2, th:7, oo:agu, t_bar:0.6"]
lin = ["k:", "k-o", "k-s", "k--"]
try:
    for key, l in zip(keys, lin):
        m = d[key]
        plt.figure(1, figsize=(5,5))
        m.do_growth_vs_distance_ss_plot(newfigure=False, lin=l, labels=False,
                                        markevery=300,
                                        label=r'$\theta = ' +
                                        str(m.theta) + '$',
                                        lw=1)
        plt.xlabel(r'$\log \left(y_t/y_{ss}\right)$')
        plt.ylabel(r'$\log \left(y_{t+1}/y_t\right)$ / T')
        plt.figure(2,  figsize=(5,5))
        m.do_change_assetoutput_vs_growth_plot(newfigure=False, lin=l,
                                               labels=False, markevery=300,
                                               label=r'$\theta = ' +
                                               str(m.theta) + '$',
                                               lw=1)
        plt.ylabel(r'$\log \left(y_{t+1}/y_{t}\right) / T$')
        plt.xlabel(r'$- (b_{t+1}/y_{t+1} - b_t / y_{t} ) / T$')
        plt.figure(3,  figsize=(5,5))
        plt.plot(log(m.f(m.kmap['kt'])/m.f(m.kss)),
                 (- (m.valuefunction(m.wpol(m.valuefunctiondomain)) -
                     m.valuefunction(m.valuefunctiondomain)) +
                  m.kpol(m.wpol(m.valuefunctiondomain)) - (1 - m.d) *
                  m.kpol(m.valuefunctiondomain)) / 
                 m.f(m.kpol(m.valuefunctiondomain)), 
                 l, markevery=300, label=r'$\theta = ' + str(m.theta) + '$',
                 lw=1)
        plt.xlabel(r'$\log \left(y_{t}/y_{ss}\right)$')
        plt.ylabel(r'savings rate') #  = $(- (b_{t+1} - b_t) + i_t) /  y_t$')
    plt.figure(1)
    plt.xlim([-0.4, 0])
    plt.ylim([0, 0.065])
    plt.xticks([-.3, -.2, -.1, 0])
    plt.yticks([0, 0.02, .04, .06])
    plt.legend(loc=0)
    plt.savefig("plotIV." + fig_format, format=fig_format)
    plt.figure(2)
    plt.xlim([0, 0.02])
    plt.ylim([0, 0.02])
    plt.xticks([0, 0.005, 0.010, 0.015, 0.020])
    plt.yticks([0.005, 0.010, 0.015, 0.020], ['', '0.01', '', '0.02'])
    plt.legend(loc=0)
    plt.savefig("plotVI."+ fig_format, format=fig_format)    
    plt.figure(3)
    plt.legend(loc=0)
    plt.xlim([-0.4, 0])
    plt.ylim([0, 0.9])
    plt.xticks([-.3, -.2, -.1, 0])
    plt.yticks([0, 0.2, .4, .6, .8])
    plt.savefig("plotV." + fig_format, format=fig_format)
finally:
    d.close()
